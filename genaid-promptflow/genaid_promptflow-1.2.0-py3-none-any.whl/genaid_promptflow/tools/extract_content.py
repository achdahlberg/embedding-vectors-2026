from promptflow.core import tool
from langchain_core.documents import Document

@tool
def extract_page_content(doc: Document) -> str:
    """
    # GA Extract Content

    Extracts the page_content from a Document object.

    :param doc (Document): The `Document` object from which we want to extract the content.
    
    :return: The string content of the `Document`.
    :rtype: str
    """
    return doc.page_content
