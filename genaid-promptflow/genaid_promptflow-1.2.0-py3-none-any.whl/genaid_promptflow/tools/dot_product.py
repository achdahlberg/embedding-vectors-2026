import numpy as np
from promptflow.core import tool
from langchain_core.embeddings.embeddings import Embeddings

@tool
def calculate_dot_product(embeddings: Embeddings, text1: str, text2: str) -> float:
    """
    # GA Dot Product

    Gives the dot product between the embedding vectors of two texts.

    :param: embeddings (Embeddings): The `Embeddings` model for converting the texts into vector form.
    :param: text1 (str): The first text to convert.
    :param: text2 (str): The second text to convert.

    :return: The dot product between the embedding vectors of the two input texts.
    :rtype: float
    """
    vector1 = embeddings.embed_query(text1)
    vector2 = embeddings.embed_query(text2)

    a = np.array(vector1)
    b = np.array(vector2)
    
    return np.dot(a,b)