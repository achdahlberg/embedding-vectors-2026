from promptflow.core import tool
import string
from math import floor

@tool
def normalize_and_truncate_words(query: str, ignore_below: int, include_percent: int) -> str:
    """
    # GA Normalize Query

    Modifies a given query in the following way:
    - removes punctuation,
    - removes words from the query with length less than `ignore_below`,
    - cuts away the ends of the words so that for each `word` in the query the resulting word has the length of
    at most `(include_percent / 100) * len(word)`.

    For example, `normalize_and_truncate_words("this is a query from someone.", 4, 50)` returns the string `"th que fr some"`.

    :param: query (str): The input text to modify.
    :param: ignore below (int): If the length of the word is shorter than this parameter, it will be removed.
    :param: include_percent (int): The percentage of the word that will be included in the output with respect to the length (`0` removes all of the word, `100` removes nothing).

    :return: The string after modifying it the way described above.
    :rtype: str
    """
    translator = str.maketrans('', '', string.punctuation)
    clean_query = query.translate(translator)   # remove punctuation
    
    cq_list = clean_query.split()   # split the string into a list of words
    words = []
    for a in cq_list:
        if len(a) >= ignore_below:
            words.append(a)         # add only long enough words to a new list

    ip_coef = 0
    if include_percent <= 0:
        return ""
    elif include_percent >= 100:
        return " ".join(words)
    else:
        ip_coef = include_percent / 100
    
    new_words = []
    for a in words:
        l = floor(ip_coef * len(a))
        new_words.append(a[0:l])

    return " ".join(new_words)