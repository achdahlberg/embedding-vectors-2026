from promptflow.core import tool
from langchain_core.documents import Document

@tool
def join_and_format_documents(documents: list[Document], add_index: bool = True, delim: str = "\n\n", **kwargs) -> Document:
    """
    # GA Join Documents

    Joins and formats the string contents of `Document` objects into a single string and returns it as a single `Document` with added metadata about the contents length. Optionally, a running index is added as a prefix, and a set of labels and values is added as a suffix to the contents of each `Document` entry according to given parameters and the `Document` metadata.

    For example, given the following `Document` metadata:
    ```
    doc.metadata["size"] = 2344
    doc.metadata["file"] = "abc.txt"
    ```
    and the following parameters:
    ```
    kwargs["size"] = "file_size"
    kwargs["file"] = "filename"
    kwargs["source"] = "internet"
    ```
    the resulting suffix is `(filename: abc.txt, file_size: 2344)`. Note that any key not present in the document metadata are ignored (like "source" in the example above).

    Additional metadata for the resulting `Document`:
    - "ga_total_length": Total number of characters of the resulting document.
    - "ga_normalized_length": Total number of characters from all input document contents combined.

    :param: documents (list[Document]): The list of `Document` objects to join together.
    :param: add_index (bool): Whether to add running index number in front of the contents of each `Document`.
    :param: delim (str): The string to use between each `Document` entry in the resulting string.
    :param: **kwargs (dict[str, any]): A dictionary whose keys are used to get the document metadata and values are used  in the resulting string as labels for the metadata.
    
    :returns: A `Document` combined from the contents of the `Document` objects formatted according to given parameters.
    :rtype: Document
    """

    formatted_contents = [
        format_document(add_index, index, doc, kwargs)
        for index, doc in enumerate(documents)
    ]

    page_content = delim.join(formatted_contents)
    total_length = len(page_content)
    normalized_length = sum(len(doc.page_content) for doc in documents)

    return Document(
        page_content=page_content,
        metadata={
            "ga_total_length": total_length,
            "ga_normalized_length": normalized_length,
            }
    )

def format_document(add_index: bool, index: int, doc: Document, kwargs) -> str:
    metadata_items = []
    for key, label in kwargs.items():
        if key in doc.metadata:
            metadata_items.append(f"{label}: {doc.metadata[key]}")

    suffix = ""
    if metadata_items:
        suffix = " (" + ", ".join(metadata_items) + ")"
    prefix = ""
    if add_index:
        prefix = f"{index+1}: "

    return prefix + doc.page_content + suffix