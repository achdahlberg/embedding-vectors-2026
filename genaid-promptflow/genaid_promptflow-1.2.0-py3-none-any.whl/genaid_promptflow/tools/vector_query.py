import json
from pathlib import Path
from typing import List
from promptflow.core import tool
from langchain_core.documents import Document
from langchain_community.vectorstores import VectorStore


@tool
def query_vector_store(
    vectorstore: VectorStore | None, query: str, how_many: int
) -> List[Document]:
    """
    # GA Vector Query

    Returns a list consisting of a given number of potentially relevant `Document` data entries with respect to the given query.
    The data entries have already been embedded in the `VectorStore` input using **GA Vectors / vectors.py**.

    Additional metadata for the resulting `Document` objects:
    - "ga_vector_relevance_score": The relevance score for the document from the vectory query.

    :param: vectorstore (VectorStore): The `VectorStore` containing the embedded data chunks, created using **GA Vectors / vectors.py**.
    :param: query (str): The query for which the tool tries to find the answers.
    :param: how_many (int): The amount of `Document` data chunks in the output list.

    :return: List of `Document` objects that match the query the best according to the vectorstore.
    :rtype: list[Document]
    """

    if vectorstore is None:
        return []

    document_score_pairs = vectorstore.similarity_search_with_relevance_scores(
        query, k=how_many * 3
    )
    document_score_pairs.sort(key=lambda pair: pair[1], reverse=True)

    results: List[Document] = []
    returned_original_hashes: set = set()

    for document, score in document_score_pairs:
        if len(results) >= how_many:
            break

        original_document_hash = document.metadata.get("_ga_original_document_hash")

        if original_document_hash is None:
            results.append(
                Document(
                    page_content=document.page_content,
                    metadata={
                        **(document.metadata or {}),
                        "ga_vector_relevance_score": float(score),
                    },
                )
            )
            continue

        cache_digest = document.metadata.get("_ga_cache_digest")
        vector_store_path = document.metadata.get("_ga_vector_store_path")

        if (
            original_document_hash
            and cache_digest
            and vector_store_path
            and original_document_hash not in returned_original_hashes
        ):
            original_file_path = (
                Path(vector_store_path)
                / "data"
                / cache_digest
                / f"{original_document_hash}.json"
            )
            if original_file_path.exists():
                try:
                    with open(original_file_path, "r", encoding="utf-8") as f:
                        payload = json.load(f)
                    results.append(
                        Document(
                            page_content=payload["page_content"],
                            metadata={
                                **(payload.get("metadata", {})),
                                "ga_vector_relevance_score": float(score),
                            },
                        )
                    )
                    returned_original_hashes.add(original_document_hash)
                    if len(results) >= how_many:
                        break
                    continue
                except Exception:
                    pass

    return results
