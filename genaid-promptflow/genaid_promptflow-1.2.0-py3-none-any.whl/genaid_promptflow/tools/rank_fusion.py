from promptflow.core import tool

def rrs(d, K):
    score = 0.0
    for M in K:
        if d in M:
            score += 1.0 / (60 + M.index(d) + 1)    # the constant 60 comes from the paper by Cormack et al. "Reciprocal Rank Fusion outperforms Condorcet and..."
    return score

@tool
def rank_merged_list(how_many: int, **kwargs) -> list:
    """
    # GA Rank Fusion

    Takes an arbitrary number of ordered lists, merges them and returns a new list with at most the given number of entries that have been 
    ordered from best to worst with respect to the reciprocal rank score. The score is calculated using the rrs function in the file.
    
    :param: how_many (int): The number of entries in the output list.
    :param: **kwargs (dict[str, any]): The lists to merge and rank.

    :return: The wanted number of first entries in the merged and ranked list.
    :rtype: list
    """
    L = [a for a in list(kwargs.values())]
    values = []
    scores = []

    for M in L:                                     # calculate the reciprocal rank score for each entry only once
        for d in M:
            if d not in values:
                values.append(d)
                scores.append(rrs(d,L))

    N = list(zip(values,scores))                    # make on list by pairing each entry with its reciprocal rank score
    N.sort(key=lambda tup: tup[1], reverse=True)    # sort the list from best to worst with respect to the score
    O = [x[0] for x in N]                           # take the entries without the scores in the correct order

    if how_many >= len(O):
        return O
    else:
        return O[0:how_many]