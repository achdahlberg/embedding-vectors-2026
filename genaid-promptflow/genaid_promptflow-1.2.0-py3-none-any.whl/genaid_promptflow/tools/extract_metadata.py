from promptflow.core import tool
from langchain_core.documents import Document

@tool
def extract_metadata_value(doc: Document, key: str) -> str:
    """
    # GA Extract Metadata

    Extracts the metadata value for the given key from a `Document`.

    :param doc (Document): The Document object from which to extract metadata.
    :param key (str): The metadata key to look up.

    :return: The value associated with the key, or empty string if the key is not present.
    :rtype: str
    """
    return str(doc.metadata.get(key)) if key in doc.metadata else ""