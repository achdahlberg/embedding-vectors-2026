from promptflow.core import tool
from promptflow.contracts.types import FilePath
from langchain_core.documents import Document
import csv

@tool
def read_csv_to_documents(
    file_path: FilePath,
    content_column: str,
    delimiter: str =";",
    **kwargs
) -> list[Document]:
    """
    # GA CSV to Documents

    Reads a CSV file and creates a `Document` object from each row in the file according to the file header row.

    Additional metadata for the resulting `Document`:
    - "ga_csv_file_row": The row number of the document in the source file read.
    
    :param: file_path (FilePath): The `FilePath` for the CSV file to read.
    :param: content_column (str): The name of the CSV file column to read to `Document` content text.
    :param: delimiter (str): The column delimiter to use in reading the CSV file.
    :param: **kwargs (dict[str, any]): Optional column names to read as the `Document` metadata of a given label.

    :return: The list of `Document` objects corresponding to the rows in the CSV file.
    :rtype: list[Document]
    """
    docs: list[Document] = []
    with open(file_path, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f, delimiter=delimiter)
        if reader.fieldnames and content_column not in reader.fieldnames:
            raise KeyError( f"CSV missing '{content_column}' column. Found: {reader.fieldnames}" )
        for i, row in enumerate(reader):
            content = row.get(content_column, "") or ""
            metadata = {}
            metadata["ga_csv_file_row"] = i
            for key, label in kwargs.items():
                metadata[label] = row.get(key, "") or ""
            docs.append(Document(page_content=content, metadata=metadata))
    return docs