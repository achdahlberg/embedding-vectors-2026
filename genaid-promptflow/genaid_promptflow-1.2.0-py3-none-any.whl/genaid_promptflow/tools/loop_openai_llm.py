from promptflow.core import tool
from promptflow.connections import AzureOpenAIConnection
from promptflow.contracts.types import PromptTemplate
from genaid_promptflow.tools.openai_llm import chat_with_openai_llm

@tool
def loop_chat_with_openai_llm(
    connection: AzureOpenAIConnection,
    deployment_name: str,
    model_temperature: float,
    response_length: int,
    prompt: PromptTemplate,
    _inputs_to_escape: list[str],
    **kwargs
) -> list[str]:
    """
    # GA Loop OpenAI LLM

    An LLM tool for Azure OpenAI models with multiple inputs and outputs. Note that the tool assumes the named template parameters (**kwargs)
    to be of type `list[any]` and to be of equal length.
    
    :param: connection (AzureOpenAIConnection): The connection object to use.
    :param: deployment_name (str): The deployment name configured in Azure.
    :param: model_temperature (float): The temperature parameter for the model.
    :param: response_length (int): The maximum length of the response given by the model.
    :param: prompt (PromptTemplate): The instructions to the model.
    :param: _inputs_to_escape (list[str]): Capture and discard the internal parameter to prevent the inputs of type `FLOW_INPUT` from being escaped and handled as a string instead of a list, which is needed here. For reference, see the nominal steps at https://github.com/microsoft/promptflow/blob/40ebb65a82851c04e8dee81314d8831c7e047d3a/src/promptflow-core/promptflow/executor/_tool_resolver.py#L532
    :param: **kwargs (dict[str, list[any]]): Additional parameter arrays defined in the prompt (such as a query and a context).
    
    :return: The list of outputs given by the model.
    :rtype: list[str]
    """
    responses = []
    
    count = 0
    for key, value in kwargs.items():
        count = len(value)
        break

    args = {}
    for index in range(count):
        for key, value in kwargs.items():
            args[key] = value[index]
        responses.append(chat_with_openai_llm(connection, deployment_name, model_temperature, response_length, prompt, **args))

    return responses