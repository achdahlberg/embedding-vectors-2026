from promptflow.core import tool
from langchain_core.embeddings.embeddings import Embeddings
import numpy as np

@tool
def compute_median_coordinate_change(embeddings: Embeddings, text1: str, text2: str, min_max_all: str = "all", how_many: int = 1) -> float:
    """
    # GA Coordinate Change Median

    Computes the median changes in coordinate distances between the embedding vectors of two texts. Computes the median changes for all the changes or the given number of biggest or smallest changes, depending on the parameters `min_max_all` and `how_many`. Returns the median corresponding to the given parameters.

    For example, compute_median_coordinate_changes(model, text1, text2, "min", 100) computes the median of the smallest 100 changes between the embedding vectors. If the `min_max_all` parameter is set to "all", the `how_many` parameter will be ignored.  

    :param: embeddings (Embeddings): The `Embeddings` model for converting the texts into vector form.
    :param: text1 (str): The first text to convert.
    :param: text2 (str): The second text to convert.
    :param: min_max_all (str): The accepted values are "min" (for the smallest changes), "max" (for the biggest changes), and "all" (for all changes).
    :param: how_many (int): The number of changes used to compute the median; the parameter will be ignored if `min_max_all` is set to "all".

    :return: The median of the smallest or biggest or all changes between the embedding vectors of two texts.
    :rtype: float
    """

    # check that the `min_max_all` parameter is correct
    if min_max_all != "min" and min_max_all != "max" and min_max_all != "all":
        raise ValueError('Incorrect value for the parameter min_max_all.')
    
    # get the embedding vectors and compute the coordinate changes
    vector1 = np.array(embeddings.embed_query(text1))
    vector2 = np.array(embeddings.embed_query(text2))
    distances = np.absolute(vector1 - vector2)

    # check that the `how_many` parameter is correct (but ignore it if the `min_max_all` parameter is set to "all")
    if min_max_all != "all":
        if how_many < 1 or how_many > len(distances):
            raise ValueError('Incorrect value for the parameter how_many.')
        
    if min_max_all == "all":
        return np.median(distances)
    
    if min_max_all == "min":
        distances.sort()
        return np.median(distances[0:how_many])
    
    if min_max_all == "max":
        distances[::-1].sort()
        return np.median(distances[0:how_many])