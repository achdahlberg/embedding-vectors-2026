from promptflow.core import tool
from langchain_core.documents import Document

@tool
def split_string_to_documents(input: str, sep: str, **kwargs) -> list[Document]:
    """
    # GA Split To Documents

    Splits a given string into a list of `Document` objects. The splitting is done with respect to the `sep` parameter. 
    Adds the optional input parameters to the `Document` metadata.

    :param: input (str): The string to split into a list of `Document` objects.
    :param: sep (str): The separator for the splitting, i.e., the string that is used as the separator between the data chunks.
    :param: **kwargs (dict[str, any]): Optional input parameters to add as the `Document` metadata.

    :return: The input string split into list of `Document` objects with the optional input parameters as the metadata.
    :rtype: list[Document]
    """
    return list(map(lambda item: Document(page_content=item, metadata={**kwargs}), input.split(sep)))