from sklearn.feature_extraction.text import TfidfVectorizer
from promptflow.core import tool
from sklearn.metrics.pairwise import cosine_similarity
from langchain_core.documents import Document

@tool
def tf_idf_search(docs: list[Document], query: str, how_many: int) -> list[Document]:
    """
    # GA tf-idf

    Searches for the best matches from a given list of `Document` objects for a given query with respect to tf-idf (https://en.wikipedia.org/wiki/Tf%E2%80%93idf).
    The tool matches each word that contains one of the query words as a substring and adds the tf-idf score to the `Document` metadata in the output list with the key "ga_tf_idf_score".

    :param: docs (list[Document]): The context for the search, i.e., the list of `Document` data chunks to go through for the query.
    :param: query (str): The query for which the tool tries to find the matches or answers.
    :param: how_many (int): The amount of `Document` data chunks in the output list.

    :return: List of `Document` objects that match the query the best according to tf-idf.
    :rtype: list[Document]
    """
    conts = [x.page_content for x in docs]      # take just the page contents as strings for the TfidfVectorizer
    vectorizer = TfidfVectorizer()
    tfidf = vectorizer.fit_transform(conts)
    words = []
    query_words = query.split()
    terms_keys = list(vectorizer.vocabulary_.keys())

    for word in query_words:
        for context_word in terms_keys:
            if word.lower() in context_word.lower():
                words.append(context_word)
    new_query = " ".join(words)

    query_vec = vectorizer.transform([new_query])
    results = cosine_similarity(tfidf,query_vec).reshape((-1,))

    N = list(zip(docs,results))                     # make on list by pairing each original Document entry with the corresponding tf-idf score
    N.sort(key=lambda tup: tup[1], reverse=True)    # sort the list from best to worst with respect to the score
    O = [x[0] for x in N]                           # take just the values without the scores
    for i in range(0,len(O)):
        O[i].metadata["ga_tf_idf_score"] = N[i][1]

    if how_many >= len(O):
        return O
    else:
        return O[0:how_many]