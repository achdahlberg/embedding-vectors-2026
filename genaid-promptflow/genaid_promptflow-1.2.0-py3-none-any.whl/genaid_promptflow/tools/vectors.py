import os
import os.path
import json
import hashlib
from pathlib import Path
from typing import List, Dict
from promptflow.core import tool
from langchain_community.vectorstores import FAISS
from langchain_community.vectorstores import VectorStore
from langchain_core.embeddings.embeddings import Embeddings
from langchain_core.documents import Document
from langchain.text_splitter import TextSplitter


@tool
def create_vectors(
    embeddings: Embeddings,
    data: List[Document],
    text_splitter: TextSplitter | None = None,
) -> VectorStore | None:
    """
    # GA Vectors

    Creates embedded vectors from the given list of data entries, using the given `Embeddings` object.
    Returns a `VectorStore` containing the resulting embedded vectors. The embedded vectors are
    cached in a local `/vectors/{model}/` folder.

    :param: embeddings (Embeddings): The embedding to use, created using the **GA OpenAI Embedding Model** tool or the **GA Open Embedding Model** tool.
    :param: data (list[Document]): The list of documents to embed and add to the `VectorStore`.
    :param text_splitter: TextSplitter: An optional text splitter used to create chunks from the input documents.

    :return: The `VectorStore` object containing the embedded vectors.
    :rtype: VectorStore
    """

    if len(data) is 0:
        return None

    original_documents_by_hash: Dict[str, Document] = {}
    all_split_texts: List[str] = []
    splits_by_document_hash: Dict[str, List[str]] = {}

    for original_document in data:
        original_document_hash = hashlib.sha256(
            original_document.page_content.encode("utf-8")
        ).hexdigest()
        original_documents_by_hash[original_document_hash] = original_document

        if text_splitter is not None:
            split_texts = text_splitter.split_text(original_document.page_content) or [
                original_document.page_content
            ]
        else:
            split_texts = [original_document.page_content]
        splits_by_document_hash[original_document_hash] = split_texts
        all_split_texts.extend(split_texts)

    joined_split_texts = "|".join(all_split_texts)
    split_cache_digest = hashlib.sha256(joined_split_texts.encode("utf-8")).hexdigest()

    embedding_model_name: str = getattr(embeddings, "model")
    embedding_model_name = embedding_model_name.replace(":", "_")
    vector_store_path = f"vectors/{embedding_model_name}"

    if not os.path.isfile(f"{vector_store_path}/{split_cache_digest}.faiss"):
        originals_path = Path(vector_store_path) / "data" / split_cache_digest
        originals_path.mkdir(parents=True, exist_ok=True)

        for original_hash, original_document in original_documents_by_hash.items():
            with open(
                originals_path / f"{original_hash}.json", "w", encoding="utf-8"
            ) as f:
                json.dump(
                    {
                        "page_content": original_document.page_content,
                        "metadata": original_document.metadata or {},
                    },
                    f,
                    ensure_ascii=False,
                )

        chunk_documents: List[Document] = []
        for original_hash, split_texts in splits_by_document_hash.items():
            for chunk_index, chunk_text in enumerate(split_texts):
                metadata = dict(
                    original_documents_by_hash[original_hash].metadata or {}
                )
                metadata.update(
                    {
                        "_ga_original_document_hash": original_hash,
                        "_ga_chunk_index": chunk_index,
                        "_ga_cache_digest": split_cache_digest,
                        "_ga_vector_store_path": vector_store_path,
                    }
                )
                chunk_documents.append(
                    Document(page_content=chunk_text, metadata=metadata)
                )

        FAISS.from_documents(chunk_documents, embeddings).save_local(
            vector_store_path, split_cache_digest
        )

    return FAISS.load_local(
        folder_path=vector_store_path,
        embeddings=embeddings,
        index_name=split_cache_digest,
        allow_dangerous_deserialization=True,
    )
