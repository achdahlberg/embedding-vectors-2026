from promptflow.core import tool
from langchain_core.documents import Document
from genaid_promptflow.tools.extract_content import extract_page_content

@tool
def loop_extract_page_content(docs: list[Document]) -> list[str]:
    """
    # GA Loop Extract Content

    Extracts the page_contents from a list of Document objects.

    :param docs (list[Document]): The `Document` list from which we want to extract the contents.
    
    :return: The string contents of the `Document` list as an array.
    :rtype: list[str]
    """
    contents = []
    for doc in docs:
        contents.append(extract_page_content(doc))
    return contents