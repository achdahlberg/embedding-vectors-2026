from promptflow.core import tool
from langchain_core.documents import Document

@tool
def extract_section_from_document(doc: Document, start: str, end: str, start_inclusive: bool = True, end_inclusive: bool = False) -> Document:
    """
    # GA Extract Section

    Extracts a section of the document between the given start and end strings.

    Additional metadata for the resulting `Document`:
    - "ga_total_length": Total number of characters of the resulting document.
    - "ga_extracted_section_start": The string used as the start delimiter.
    - "ga_extracted_section_end": The string used as the end delimiter.

    :param doc (Document): The Document object to extract content from.
    :param start (str): The start string to search for. Use "[SOF]" to indicate start of file.
    :param end (str): The end string to search for. Use "[EOF]" to indicate end of file.
    :param start_inclusive (bool): Whether to include the start string in the result.
    :param end_inclusive (bool): Whether to include the end string in the result.

    :return: A new `Document` with the extracted content, or empty string if boundaries are not found.
    :rtype: `Document`
    """
    content = doc.page_content

    if start == "[SOF]":
        start_idx = 0
    else:
        start_idx = content.find(start)
        if start_idx == -1:
            return Document(
                page_content="",
                metadata={
                    **doc.metadata,
                    "ga_total_length": 0
                }
            )
        if not start_inclusive:
            start_idx += len(start)

    if end == "[EOF]":
        end_idx = len(content)
    else:
        end_idx = content.find(end, start_idx)
        if end_idx == -1:
            return Document(
                page_content="",
                metadata={
                    **doc.metadata,
                    "ga_total_length": 0
                }
            )
        if end_inclusive:
            end_idx += len(end)

    extracted = content[start_idx:end_idx]

    return Document(
        page_content=extracted,
        metadata={
            **doc.metadata,
            "ga_total_length": len(extracted),
            "ga_extracted_section_start": start,
            "ga_extracted_section_end": end
        }
    )
