from promptflow.core import tool
from langchain_core.documents import Document
from genaid_promptflow.tools.join_documents import join_and_format_documents

@tool
def loop_join_and_format_documents(document_lists: list[list[Document]], add_index: bool = True, delim: str = "\n\n", **kwargs) -> list[Document]:
    """
    # GA Loop Join Documents

    Joins and formats the string contents of a list of list of `Document` objects into a single list of strings and returns it as a single 
    `Document` list with added metadata about the contents lengths. Optionally, a running index is added as a prefix, and a set
    of labels and values is added as a suffix to the contents of each `Document` entry of each list according to given parameters and
    the `Document` metadata.

    For example, given the following `Document` metadata:
    ```
    doc.metadata["size"] = 2344
    doc.metadata["file"] = "abc.txt"
    ```
    and the following parameters:
    ```
    kwargs["size"] = "file_size"
    kwargs["file"] = "filename"
    kwargs["source"] = "internet"
    ```
    the resulting suffix is `(filename: abc.txt, file_size: 2344)`. Note that any key not present in the document metadata are
    ignored (like "source" in the example above).

    Additional metadata for the resulting `Document` objects:
    - "ga_total_length": Total number of characters of the resulting document.
    - "ga_normalized_length": Total number of characters from all input document contents combined.

    :param: document_lists (list[list[Document]]): The list of list of `Document` objects to join together.
    :param: add_index (bool): Whether to add running index number in front of the contents of each `Document`.
    :param: delim (str): The string to use between each `Document` entry in the resulting string.
    :param: **kwargs (dict[str, any]): A dictionary whose keys are used to get the document metadata and values are used  in the
    resulting string as labels for the metadata.
    
    :returns: A list of `Document` objects combined from the contents of the list of list of `Document` objects formatted according to given parameters.
    :rtype: list[Document]
    """
    docs = []
    for document_list in document_lists:
        docs.append(join_and_format_documents(document_list, add_index, delim, **kwargs))
    return docs