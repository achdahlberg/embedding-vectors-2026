import numpy as np
from promptflow.core import tool
from numpy.linalg import norm
from langchain_core.embeddings.embeddings import Embeddings

@tool
def calculate_euclidean_norm(embeddings: Embeddings, text: str) -> float:
    """
    # GA Euclidean Norm

    Gives the Euclidean norm of the embedding vector of the given text.

    :param: embeddings (Embeddings): The `Embeddings` model for converting the texts into vector form.
    :param: text (str): The text to convert.

    :return: The Euclidean norm of the embedding vector of the input text.
    :rtype: float
    """
    vector = embeddings.embed_query(text)

    a = np.array(vector)
    
    return norm(a)