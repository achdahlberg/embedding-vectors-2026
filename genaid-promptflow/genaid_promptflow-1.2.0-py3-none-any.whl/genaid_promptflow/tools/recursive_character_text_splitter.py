from promptflow.core import tool
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_text_splitters import TextSplitter


@tool
def create_recursive_character_text_splitter(size: int, overlap: int) -> TextSplitter:
    """
    # GA Recursive Character Text Splitter

    Creates a RecursiveCharacterTextSplitter with given chunk size and overlap parameters.

    :param: size (int): The size for the data chunks. The output chunks do not necessarily have the exact size of the parameter.
    :param: overlap (int): The size of the overlap in the consecutive data chunks.

    :return:
    :rtype: TextSplitter
    """
    return RecursiveCharacterTextSplitter(chunk_size=size, chunk_overlap=overlap)
