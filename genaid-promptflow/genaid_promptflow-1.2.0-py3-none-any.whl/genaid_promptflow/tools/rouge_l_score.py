from rouge_score import rouge_scorer
from promptflow.core import tool

@tool
def calculate_rouge_l_score(candidate_text: str, reference_text: str) -> float:
    """
    # GA ROUGE-L Score

    Computes the ROUGE-L score for the candidate text against the reference text.

    :param: candidate_text (str): The text we want to compare to the reference text.
    :param: reference_text (str): The reference text.

    :return: The ROUGE-L score (https://en.wikipedia.org/wiki/ROUGE_(metric)) for the comparison of the two input texts.
    :rtype: float
    """
    scorer = rouge_scorer.RougeScorer(['rougeL'], use_stemmer=True)
    scores = scorer.score(reference_text, candidate_text)
    return scores['rougeL'].fmeasure
