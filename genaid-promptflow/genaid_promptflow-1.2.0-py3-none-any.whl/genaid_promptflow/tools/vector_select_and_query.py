from promptflow.core import tool
from langchain_core.documents import Document
from genaid_promptflow.tools import vector_query

@tool
def select_and_query_vector_store(query: str, vectorstore_name: str, how_many: int, **kwargs) -> list[Document]:
    """
    # GA Vector Select and Query

    Returns a list consisting of a given number of potentially relevant `Document` data entries with respect to the given query.
    The data entries have already been embedded in the `VectorStore` objects using **GA Vectors / vectors.py**. The `VectorStore` objects
    are given in the `kwargs` parameter, and the store with the name given in the `store_name` parameter is used for the query.

    :param: query (str): The query for which the tool tries to find the answers.
    :param: vectorstore_name (str): The name of the `VectorStore` object to use in the query.
    :param: how_many (int): The amount of `Document` data chunks in the output list.
    :param: **kwargs (dict[str, VectorStore]): The `VectorStore` objects containing the embedded data chunks, created using **GA Vectors / vectors.py**.

    :return: List of `Document` objects that match the query the best according to the vectorstore.
    :rtype: list[Document]
    """
    return vector_query.query_vector_store(kwargs.get(vectorstore_name), query, how_many)