from promptflow.core import tool
import string

@tool
def remove_duplicate_words(query: str) -> str:
    """
    # GA Remove Duplicates

    Removes the punctuation and duplicate words from a string. Returns the string in lowercase.

    :param: query (str): The text to process.

    :return: The input string in lowercase with duplicate words and punctuation removed.
    :rtype: str
    """
    translator = str.maketrans('', '', string.punctuation)
    clean_query = query.translate(translator).lower()   # remove punctuation and transform string into lowercase
    
    cq_list = clean_query.split()   # split the string into a list of words
    words = []
    for a in cq_list:
        if a not in words:
            words.append(a)
    
    return " ".join(words)