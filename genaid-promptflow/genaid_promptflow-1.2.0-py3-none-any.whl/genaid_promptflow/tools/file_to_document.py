from promptflow.core import tool
from promptflow.contracts.types import FilePath
from langchain_core.documents import Document

@tool
def read_file_into_document(file_path: FilePath, **kwargs) -> Document:
    """
    # GA File To Document

    Reads a file, returns a `Document` with the contents of the file. Adds the file path to document metadata.

    Additional metadata for the resulting `Document`:
    - "ga_filename": The name of the source file used for the document.
    - "ga_total_length": Total number of characters of the resulting document.

    :param: file_path (FilePath): The `FilePath` for the file.
    :param: **kwargs (dict[str, any]): The optional parameters to add to the metadata of the output `Document`.

    :return: The `Document` with the contents of the file and the `FilePath` and optional parameters as the metadata.
    :rtype: Document
    """
    with open(file_path, mode="r", encoding="utf-8") as file:
        text = file.read()
    doc = Document(page_content=text, metadata={**kwargs})
    doc.metadata["ga_filename"] = file_path
    doc.metadata["ga_total_length"] = len(text)
    return doc