from promptflow.core import tool
from datetime import datetime, timezone
from dateutil.relativedelta import relativedelta
from typing import Callable
import pytz

@tool
def create_match_older_than_filter(baseline_timestamp: str | None = None, years: int = 0, months: int = 0, days: int = 0) -> Callable[[str], bool]:
    """
    # GA Match Older Than

    Creates a filter that matches timestamps older than given baseline timestamp minus the given years, months and days. If no baseline is set,
    the filter uses the current time. The timestamps to match must be in the ISO 6801 format, for example, `2022-06-19T23:11:57.000Z`

    :param: baseline_timestamp (str): The baseline to compare the relative parameter values to. The format is ISO 6801 UTC, for example, 
    `2025-08-26T13:45:20.000Z`. If not set, uses the current time in UTC.
    :param: years (int): The relative number of years to use to compare to the baseline to determine the match.
    :param: months (int): The relative number of months to use to compare to the baseline to determine the match.
    :param: days (int): The relative number of days to use to compare to the baseline to determine the match.

    :return: A filter that matches timestamps older than given baseline timestamp minus the given number of years, months and days.
    :rtype: Callable[[str], bool]
    """
    def filter(metadata_value: str) -> bool:
        utc=pytz.UTC        
        baseline = datetime.now(timezone.utc)
        if baseline_timestamp is not None:
            baseline = datetime.fromisoformat(baseline_timestamp)
        metadata_timestamp = datetime.fromisoformat(metadata_value)
        threshold = baseline - relativedelta(years=0, months=6, days=0)
        if metadata_timestamp.tzinfo is None or metadata_timestamp.tzinfo.utcoffset(metadata_timestamp) is None:
            metadata_timestamp = utc.localize(metadata_timestamp)
        if threshold.tzinfo is None or threshold.tzinfo.utcoffset(threshold) is None:
            threshold = utc.localize(threshold)
        return metadata_timestamp < threshold
    return filter