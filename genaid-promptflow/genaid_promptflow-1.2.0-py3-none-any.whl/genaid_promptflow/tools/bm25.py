from promptflow.core import tool
from langchain_core.documents import Document
from rank_bm25 import BM25Okapi

@tool
def bm25_search(docs: list[Document], query: str, how_many: int) -> list[Document]:
    """
    # GA BM25

    Applies the BM25 ranking function (https://en.wikipedia.org/wiki/Okapi_BM25) to the given list of documents and returns a given number of candidates that best fit the given query according to BM25.
    The tool matches each word that contains one of the query words as a substring and adds the BM25 score to the `Document` metadata in the output list with the key "ga_bm25_score".

    :param: docs (list[Document]): The context for the search, i.e., the list of `Document` data chunks to go through for the query.
    :param: query (str): The query for which the tool tries to find the matches or answers.
    :param: how_many (int): The amount of `Document` data chunks in the output list.

    :return: List of `Document` objects that match the query the best according to BM25.
    :rtype: list[Document]
    """
    # first we make a new query of all the words in the context that has one of the original query words as a substring
    conts = [x.page_content for x in docs]
    query_words = query.split()
    cont_str = " ".join(conts)
    cont_words = cont_str.split()

    new_query = []
    for word in query_words:
        for context_word in cont_words:
            if word.lower() in context_word.lower() and context_word not in new_query:
                new_query.append(context_word)

    # we get the BM25 scores for this new query
    tokenized_context = [doc.split(" ") for doc in conts]
    bm25 = BM25Okapi(tokenized_context)
    doc_scores = bm25.get_scores(new_query).tolist()

    # we now order the documents from best to last with respect to the BM25 scores and add the scores to metadata
    N = list(zip(docs,doc_scores))                  # make on list by pairing each original Document entry with the corresponding BM25 score
    N.sort(key=lambda tup: tup[1], reverse=True)    # sort the list from best to worst with respect to the score
    O = [x[0] for x in N]                           # take just the values without the scores
    for i in range(0,len(O)):
        O[i].metadata["ga_bm25_score"] = N[i][1]

    if how_many >= len(O):
        return O
    else:
        return O[0:how_many]