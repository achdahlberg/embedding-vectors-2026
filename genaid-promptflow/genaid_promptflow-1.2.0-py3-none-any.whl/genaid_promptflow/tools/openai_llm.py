from promptflow.core import tool
from promptflow.contracts.types import PromptTemplate
from jinja2 import Template
from langchain_openai import AzureChatOpenAI
from promptflow.connections import AzureOpenAIConnection

@tool
def chat_with_openai_llm(
    connection: AzureOpenAIConnection,
    deployment_name: str,
    model_temperature: float,
    response_length: int,
    prompt: PromptTemplate,
    **kwargs
) -> str:
    """
    # GA OpenAI LLM

    An LLM tool for Azure OpenAI models.
    
    :param: connection (AzureOpenAIConnection): The connection object to use.
    :param: deployment_name (str): The deployment name configured in Azure.
    :param: model_temperature (float): The temperature parameter for the model.
    :param: response_length (int): The maximum length of the response given by the model.
    :param: prompt (PromptTemplate): The instructions to the model.
    :param: **kwargs (dict[str, any]): Additional parameters defined in the prompt (such as a query and a context).

    :return: The output given by the model.
    :rtype: str
    """
    llm = AzureChatOpenAI(
        azure_endpoint=connection.api_base,
        api_key=connection.api_key,
        temperature=model_temperature,
        max_tokens=response_length,
        azure_deployment=deployment_name,
        api_version=connection.api_version
    )

    msg = llm.invoke(Template(prompt, trim_blocks=True, keep_trailing_newline=True).render(**kwargs))
    return msg.content