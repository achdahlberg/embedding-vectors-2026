from langchain_core.documents import Document
from promptflow.core import tool
from typing import Callable

@tool
def remove_matching_documents_by_metadata(docs: list[Document], metadata_key: str, filter: Callable[[str], bool]) -> list[Document]:
    """
    # GA Remove Matching by Metadata

    Takes a list of documents and creates a new list of documents by keeping those which do not match the `filter` parameter,
    given the value of metadata with key `metadata_key` of that document.

    :return: List of `Document` objects that do not match the filter.
    :rtype: list[Document]
    """
    if not docs:
        return []
    kept: list[Document] = []
    for doc in docs:
        value = doc.metadata.get(metadata_key)
        if value is None:
            continue
        if not filter(value):
            kept.append(doc)
    return kept