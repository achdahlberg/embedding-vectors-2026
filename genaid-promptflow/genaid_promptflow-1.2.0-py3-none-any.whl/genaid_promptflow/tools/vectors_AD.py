# genaid_promptflow/tools/vectors.py

from __future__ import annotations

import hashlib
import json
import os
import shutil
from pathlib import Path
from typing import Dict, List, Optional

from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_core.embeddings.embeddings import Embeddings
from langchain_core.vectorstores import VectorStore
from langchain_text_splitters import TextSplitter
from promptflow.core import tool


def _short_cache_root() -> Path:
    """
    Choose a short, writable base directory to avoid Windows MAX_PATH issues.
    Priority:
      1) GA_VECTOR_BASE env
      2) LOCALAPPDATA on Windows, else XDG_CACHE_HOME or ~/.cache
    """
    env_base = os.getenv("GA_VECTOR_BASE")
    if env_base:
        base = Path(env_base)
    elif os.name == "nt":
        base = Path(os.getenv("LOCALAPPDATA", r"C:\ga_cache"))
    else:
        base = Path(os.getenv("XDG_CACHE_HOME", Path.home() / ".cache"))
    return base / "ga_vectors"


@tool
def create_vectors(
    embeddings: Embeddings,
    data: List[Document],
    text_splitter: Optional[TextSplitter] = None,
) -> Optional[VectorStore]:
    """
    GA Vectors

    Creates embedded vectors from the given list of documents using the provided
    LangChain Embeddings. Returns a VectorStore containing the embedded vectors.
    Caches are stored per model and dimension to prevent collisions.
    """

    if not data:
        return None

    # 1) Collect originals and text splits
    original_documents_by_hash: Dict[str, Document] = {}
    all_split_texts: List[str] = []
    splits_by_document_hash: Dict[str, List[str]] = {}

    for original_document in data:
        original_document_hash = hashlib.sha256(
            original_document.page_content.encode("utf-8")
        ).hexdigest()
        original_documents_by_hash[original_document_hash] = original_document

        if text_splitter is not None:
            split_texts = text_splitter.split_text(original_document.page_content) or [
                original_document.page_content
            ]
        else:
            split_texts = [original_document.page_content]

        splits_by_document_hash[original_document_hash] = split_texts
        all_split_texts.extend(split_texts)

    joined_split_texts = "|".join(all_split_texts)
    split_cache_digest = hashlib.sha256(joined_split_texts.encode("utf-8")).hexdigest()
    digest_short = split_cache_digest[:16]  # short key avoids deep paths

    # 2) Probe embedding dimension once and build a short cache path
    probe_vec = embeddings.embed_query("ga_dim_probe")
    dim = len(probe_vec)

    embedding_model_name: str = getattr(embeddings, "model", "unknown")
    safe_model = embedding_model_name.replace(":", "_")

    base_root = _short_cache_root()
    base_root.mkdir(parents=True, exist_ok=True)

    # vectors/<model>_d<dim>
    vector_store_path = base_root / f"{safe_model}_d{dim}"
    vector_store_path.mkdir(parents=True, exist_ok=True)

    print(
        f"[GA Vectors] model={embedding_model_name} dim={dim} path={vector_store_path}",
        flush=True,
    )

    # 3) Ensure per-digest data folder exists before any writes
    originals_path = vector_store_path / "data" / digest_short
    originals_path.mkdir(parents=True, exist_ok=True)

    # 4) Persist the original docs for provenance
    for original_hash, original_document in original_documents_by_hash.items():
        with open(originals_path / f"{original_hash}.json", "w", encoding="utf-8") as f:
            json.dump(
                {
                    "page_content": original_document.page_content,
                    "metadata": original_document.metadata or {},
                },
                f,
                ensure_ascii=False,
            )

    # 5) Build chunk documents with helpful metadata
    chunk_documents: List[Document] = []
    for original_hash, split_texts in splits_by_document_hash.items():
        for chunk_index, chunk_text in enumerate(split_texts):
            metadata = dict(original_documents_by_hash[original_hash].metadata or {})
            metadata.update(
                {
                    "_ga_original_document_hash": original_hash,
                    "_ga_chunk_index": chunk_index,
                    "_ga_cache_digest": digest_short,
                    "_ga_vector_store_path": str(vector_store_path),
                }
            )
            chunk_documents.append(Document(page_content=chunk_text, metadata=metadata))

    # 6) Save FAISS to disk, then load as VectorStore
    try:
        FAISS.from_documents(chunk_documents, embeddings).save_local(
            str(vector_store_path),  # cast Path to str for cross-platform compatibility
            digest_short,
        )
    except Exception as e:
        # If a half-written or incompatible cache exists, wipe and retry once
        print(
            f"[GA Vectors] save_local failed ({e}), wiping and retrying…",
            flush=True,
        )
        shutil.rmtree(vector_store_path / "index", ignore_errors=True)
        shutil.rmtree(vector_store_path / "data" / digest_short, ignore_errors=True)
        (vector_store_path / "data" / digest_short).mkdir(parents=True, exist_ok=True)
        FAISS.from_documents(chunk_documents, embeddings).save_local(
            str(vector_store_path),
            digest_short,
        )

    return FAISS.load_local(
        folder_path=str(vector_store_path),
        embeddings=embeddings,
        index_name=digest_short,
        allow_dangerous_deserialization=True,
    )
