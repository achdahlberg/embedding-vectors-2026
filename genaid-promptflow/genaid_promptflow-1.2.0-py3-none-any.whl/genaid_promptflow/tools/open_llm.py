from promptflow.core import tool
from promptflow.contracts.types import PromptTemplate
from langchain_ollama import ChatOllama
from langchain_core.messages.ai import AIMessage
from jinja2 import Template

@tool
def chat_with_open_llm(server_url: str, model_name: str, model_temperature: float, response_length: int, prompt: PromptTemplate, **kwargs) -> str:
    """
    # GA Open LLM

    LLM tool for open models on Ollama. The corresponding yaml file has to have `type: custom_llm` or the tool will not work.

    :param: server_url (str): Server URL for the model. If using a model installed on the same computer, the url is `http://127.0.0.1:11434`.
    :param: model_name (str): The name of the model (e.g., `llama3.2`).
    :param: model_temperature (float): The temperature parameter for the model.
    :param: response_length (int): The maximum length of the response given by the model.
    :param: prompt (PromptTemplate): The instructions to the model.
    :param: **kwargs (dict[str, any]): Additional parameters defined in the prompt (such as a query and context).

    :return: The output given by the model.
    :rtype: str
    """
    llm = ChatOllama(
        model=model_name,
        temperature=model_temperature,
        num_predict = response_length,
        base_url=server_url
    )
    msg : AIMessage = llm.invoke(Template(prompt, trim_blocks=True, keep_trailing_newline=True).render(**kwargs))
    llm._client._client.close()
    return msg.content