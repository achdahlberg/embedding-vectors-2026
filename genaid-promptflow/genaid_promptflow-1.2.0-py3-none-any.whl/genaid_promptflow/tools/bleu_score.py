import sacrebleu
from promptflow.core import tool

@tool
def calculate_bleu_score(candidate_text: str, reference_text: str) -> float:
    """
    # GA BLEU Score

    Computes the BLEU score (https://en.wikipedia.org/wiki/BLEU) for the candidate text against the reference text.

    :param: candidate_text (str): The text to compare to the reference text.
    :param: reference_text (str): The reference text we use to evaluate the quality of the candidate text.

    :return: The BLEU score for the candidate text against the reference text.
    :rtype: float
    """
    bleu_score = sacrebleu.corpus_bleu([candidate_text], [[reference_text]])
    return bleu_score.score / 100.0
