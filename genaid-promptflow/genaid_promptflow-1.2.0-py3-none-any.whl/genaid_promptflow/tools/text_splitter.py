from promptflow.core import tool
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents import Document

@tool
def split_document(doc: Document, size: int, overlap: int) -> list[Document]:
    """
    # GA Text Splitter

    Splits a given `Document` into chunks of given size with overlap of given size.

    :param: doc (Document): The `Document` to split.
    :param: size (int): The size for the data chunks. Since the tool uses RecursiveCharacterTextSplitter, the output chunks do not necessarily have the exact size of the parameter.
    :param: overlap (int): The size of the overlap in the consecutive data chunks.

    :return: List of `Document` data chunks created from the input `Document`.
    :rtype: list[Document]
    """
    splitter = RecursiveCharacterTextSplitter(chunk_size=size, chunk_overlap=overlap)
    return splitter.split_documents([doc])