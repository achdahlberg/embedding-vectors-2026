from promptflow.core import tool
from promptflow.contracts.types import FilePath
from langchain_core.documents import Document
from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter

@tool
def read_file_into_document_chunks(file_path: FilePath, size: int, overlap: int) -> list[Document]:
    """
    # GA Read File And Split Text

    Reads a file and splits the text into a list of `Document` chunks of given size with overlap
    of given size. Adds running indices and original file name to the metadata of the chunks.

    :param: file_path (FilePath): The file to read.
    :param: size (int): The size for the data chunks. Since the tool uses RecursiveCharacterTextSplitter, the output chunks do not necessarily have the exact size of the parameter.
    :param: overlap (int): The size of the overlap in the consecutive data chunks.

    :return: List of `Document` data chunks created from the file with running indices and original file name added to the metadata of the chunks.
    :rtype: list[Document]
    """
    document = TextLoader(file_path, encoding='utf8').load()
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=size, chunk_overlap=overlap)
    documents = text_splitter.split_documents(document)

    for index, doc in enumerate(documents):
        doc.metadata["ga_chunk_index"] = index
        doc.metadata["ga_filename"] = file_path
        doc.metadata.pop("source")      # remove the automatically added source metadata that overlaps with ga_filename

    return documents