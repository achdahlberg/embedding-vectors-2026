import csv
import os
from datetime import datetime, timezone
from promptflow.core import tool
from promptflow.contracts.types import FilePath

@tool
def append_to_csv_file(file_path: FilePath, **kwargs):
    """
    # GA Append To CSV

    Appends a set of values as a new row to a CSV file. If the file is empty, it adds the key names as column names to the first line.
    Adds a timestamp column with current time in UTC automatically.

    :param: file_path (FilePath): The `FilePath` for the CSV file where we want to add information.
    :param: **kwargs (dict[str, any]): Optional input parameters we want to add to the file.

    :return: The tool does not return anything.
    :rtype: \-
    """
    file_exists = os.path.isfile(file_path)
    file_empty = not file_exists or os.stat(file_path).st_size == 0
    kwargs['timestamp'] = datetime.now(timezone.utc).isoformat()
    
    with open(file_path, mode='a', newline='', encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=kwargs.keys(), delimiter=';')
        if file_empty:
            writer.writeheader()  # Write header if file is empty
        writer.writerow(kwargs)
