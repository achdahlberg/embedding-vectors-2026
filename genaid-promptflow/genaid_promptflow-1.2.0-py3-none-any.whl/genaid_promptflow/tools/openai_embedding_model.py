from promptflow.core import tool
from promptflow.connections import AzureOpenAIConnection
from promptflow._core.token_provider import AzureTokenProvider
from langchain_openai import AzureOpenAIEmbeddings
from langchain_core.embeddings.embeddings import Embeddings

@tool
def create_openai_embedding_model(connection: AzureOpenAIConnection, model_name: str) -> Embeddings:
    """
    # GA OpenAI Embedding Model

    Creates an embedding model for OpenAI models.
    This embedding model is needed for `GA Vectors / vectors.py` when using OpenAI models.

    :param: connection (AzureOpenAIConnection): The OpenAI connection created in the Connections section of the Prompt Flow extension using the API key and endpoint.
    :param: model_name (str): The name of the embedding model (e.g., `text-embedding-ada-002`).

    :return: The `Embeddings` object used for `GA Vectors / vectors.py`.
    :rtype: Embeddings
    """
    token_provider=None
    if connection.api_key==None:
        token_provider=lambda:AzureTokenProvider().getToken()
    return AzureOpenAIEmbeddings(model=model_name, api_key=connection.api_key, azure_endpoint=connection.api_base, azure_ad_token_provider=token_provider)