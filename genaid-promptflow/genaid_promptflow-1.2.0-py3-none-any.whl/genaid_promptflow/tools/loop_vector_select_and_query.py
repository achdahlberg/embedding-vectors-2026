from promptflow.core import tool
from langchain_core.documents import Document
from genaid_promptflow.tools import vector_query

@tool
def loop_select_and_query_vector_store(queries: list[str], vectorstore_names: list[str], how_many: int, **kwargs) -> list[list[Document]]:
    """
    # GA Loop Vector Select and Query

    Returns a list of lists consisting of a given number of potentially relevant `Document` data entries with respect to the given queries.
    The data entries have already been embedded in the `VectorStore` objects using **GA Vectors / vectors.py**. The `VectorStore` objects
    are given in the `kwargs` parameter, and the store with the name given in the `store_name` parameter is used for the query.

    :param: queries (list[str]): The queries for which the tool tries to find the answers.
    :param: vectorstore_names (list[str]): The names of the `VectorStore` objects to use in the corresponding query.
    :param: how_many (int): The amount of `Document` data chunks in the output list.
    :param: **kwargs (dict[str, VectorStore]): The `VectorStore` objects containing the embedded data chunks, created using **GA Vectors / vectors.py**.

    :return: List of list of `Document` objects that match each query the best according to the se vectorstore.
    :rtype: list[list[Document]]
    """
    docs = []
    for i, query in enumerate(queries):
        docs.append(vector_query.query_vector_store(kwargs.get(vectorstore_names[i]), query, how_many))
    return docs