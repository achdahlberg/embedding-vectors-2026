from promptflow.core import tool
from langchain_core.documents import Document
from genaid_promptflow.tools import vector_query
from langchain_community.vectorstores import VectorStore

@tool
def loop_query_vector_store(vectorstore: VectorStore, queries: list[str], how_many: int) -> list[list[Document]]:
    """
    # GA Loop Vector Query

    Returns a list of lists consisting of a given number of potentially relevant `Document` data entries with respect to the given queries.
    The data entries have already been embedded in the `VectorStore` input using **GA Vectors / vectors.py**.

    :param: vectorstore (VectorStore): The `VectorStore` containing the embedded data chunks, created using **GA Vectors / vectors.py**.
    :param: queries (list[str]): The queries for which the tool tries to find the answers.
    :param: how_many (int): The amount of `Document` data chunks in the output lists.

    :return: List of list of `Document` objects that match the each query the best according to the vectorstore.
    :rtype: list[list[Document]]
    """
    docs = []
    for query in queries:
        docs.append(vector_query.query_vector_store(vectorstore, query, how_many))
    return docs