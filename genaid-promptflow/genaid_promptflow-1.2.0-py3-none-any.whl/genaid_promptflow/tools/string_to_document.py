from promptflow.core import tool
from langchain_core.documents import Document

@tool
def convert_string_to_document(content: str, **kwargs) -> Document:
    """
    # GA String To Document

    Converts the given string into a `Document`. Adds the optional input parameters to the `Document` metadata.

    :param: content (str): The string to convert into a `Document`.
    :param: **kwargs (dict[str, any]): The optional parameters to add to the metadata of the output `Document`.

    :return: The input string in a `Document` form with the optional input parameters as the metadata.
    :rtype: Document
    """
    return Document(page_content=content, metadata={**kwargs})